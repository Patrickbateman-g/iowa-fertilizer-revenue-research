# Why Q1 shipment volume changed historical errors

All 2016–2026 outcomes were examined before this investigation. These results are exploratory, not an untouched or prospective test. The frozen price forecast remains the candidate for a future test. The damped formula was specified as a sensitivity check after the original results were known.

The full adjustment assumes Q2 sales volume changes in the same proportion as Q1; dampening uses the square root of that Q1 ratio. Neither relationship is guaranteed. Positive signed error means predicted revenue exceeded actual revenue.

## Matched historical comparisons

| Period | Model | Years | Mean absolute error ($m) |
|---|---|---:|---:|
| 2016-2021 | Frozen price | 6 | 107.3 |
| 2016-2021 | Full Q1 volume adjustment | 6 | 252.0 |
| 2016-2021 | 50%-damped Q1 volume (experimental) | 6 | 163.4 |
| 2022-2026 | Frozen price | 5 | 147.0 |
| 2022-2026 | Full Q1 volume adjustment | 5 | 79.8 |
| 2022-2026 | 50%-damped Q1 volume (experimental) | 5 | 113.4 |
| all | Frozen price | 11 | 125.3 |
| all | Full Q1 volume adjustment | 11 | 173.8 |
| all | 50%-damped Q1 volume (experimental) | 11 | 140.7 |

The full-volume adjustment raised absolute error in 6 of 6 early years and lowered it in 0. The yearly table below shows both signed errors and the increase or decrease in absolute error.

The sum of full-volume minus frozen-model absolute errors over 2016–2021 was USD 868.6 million. The 2016 contribution was USD 390.5 million (45.0% of that signed net difference).
A share can exceed 100% if other years partly offset 2016; this is a descriptive decomposition, not causation.

## Interpretation and source limits

- CF reported that adverse weather delayed the 2018 spring application season and shifted some shipments from Q1 to Q2. Q1 volume declined year over year while Q2 volume rose. This Q2 filing is an after-the-fact explanation, not a forecast input: https://www.sec.gov/Archives/edgar/data/1324404/000132440418000019/cf-06302018x10q.htm
- The 2015 acquisition of the remaining UK business and 2016 capacity changes complicate year-over-year comparisons; they do not prove the size or direction of any forecast error: https://www.cfindustries.com/globalassets/cf-industries/media/documents/reports/annual-reports/cfi_2016-annual-report.pdf
- Q1 shipment volumes are company-wide product tons, spanning different product mixes, geographies and customers; they are not Iowa corn use. The national price index is not CF’s realized price.
- The damped factor is an arbitrary sensitivity check and was considered after inspecting results. Its historical score cannot establish that it will improve future forecasts. A real prospective comparison must fix and archive the rules before future Q2 outcomes are known.
- The detailed year-by-year rows and errors remain in /kaggle/working/iowa_v4.
