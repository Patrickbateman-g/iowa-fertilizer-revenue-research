# Exploratory Iowa archived forecast test

Historical results through 2026 were already inspected. These are retrospective, not an untouched test; the frozen 2027 forecast remains unchanged.

Feature: equal-station mean GFS MOS p12 probability (%) for the 12 hours ending 24 hours after each 00Z model initialization from April 1 through May 20, in Iowa. Each station-year needs 40 of 50 days; identical duplicate values are counted once and days with conflicting values are excluded. Runtime is initialization, not verified product publication or proof a farmer saw the forecast.

A one-coefficient ridge model is fitted on earlier years only, on log(actual / price-only forecast). A training-only mean and standard deviation and fixed ridge penalty 1 are used; the intercept is fixed at zero. Minimum six earlier complete years. Actual outcomes filed after the forecast date are never used for training that forecast.

Complete forecast years: 11 of 11; matched evaluated years: 5.

| Model | Matched years | MAE (USD millions) |
|---|---:|---:|
| Existing price only | 5 | 147.0 |
| Price + forecast feature | 5 | 141.0 |

Forecast feature had lower error in 2 of 5 matched years.

Per-year predictions and training counts are in predictions_private.csv. The small sample, prior inspection, model and feature choices, missing coverage, and potentially revised archives limit interpretation. A lower error here does not establish future improvement or causation.

IEM documentation: https://mesonet.agron.iastate.edu/mos/ ; original model details: https://vlab.noaa.gov/web/mdl/mav-card .
P12 is probability of measurable precipitation, not expected rainfall amount; product issuance/public availability timing and archive revisions require verification. The compact station-year inputs were summarized via the browser; the raw records and calculations are not independently reverified by this notebook. No rain forecasts after May 20 initialization enter the feature. Station-averaged forecasts do not indicate which forecast a farmer saw or whether any order was placed.
Compare only years present for both models and use a future, pre-recorded test before promoting any candidate.
