# CF Q2 revenue: follow-up investigation

**Status:** Exploratory historical comparison. Every year through 2026 was already inspected, so no period below is an untouched final test. No candidate has been established as a reliable improvement.

## What was tested

Each forecast is made on May 31. The previous Q2 benchmark and original rainfall model are compared with fixed models using current Q1 company sales, and, where available with validated historical vintages, nitrogen producer prices. The ratio models scale previous Q2 sales by the year-on-year change in Q1 sales or April nitrogen prices. This is a nowcast, not a forecast made before Q2 begins.

## Time-ordered results

MAE is mean absolute error; MAPE is mean absolute percentage error. Lower is better. Within each cohort, all candidates use the same eligible years. Forecasts for each year use only earlier training labels filed by that year’s May 31.


### Financial models, all available years

| Period | Model | Years | MAE (USD m) | MAPE |
|---|---|---:|---:|---:|
| 2012–2021 development | Previous Q2 | 10 | 173.8 | 12.6% |
| 2012–2021 development | Original weather ridge | 10 | 249.0 | 17.1% |
| 2012–2021 development | Q1 ratio | 10 | 213.7 | 14.8% |
| 2012–2021 development | Q1 + previous Q2 ridge | 10 | 182.2 | 13.1% |
| 2022–2026 previously inspected | Previous Q2 | 5 | 853.6 | 37.8% |
| 2022–2026 previously inspected | Original weather ridge | 5 | 884.4 | 38.4% |
| 2022–2026 previously inspected | Q1 ratio | 5 | 396.2 | 17.4% |
| 2022–2026 previously inspected | Q1 + previous Q2 ridge | 5 | 299.8 | 13.0% |
| All years in cohort | Previous Q2 | 15 | 400.4 | 21.0% |
| All years in cohort | Original weather ridge | 15 | 460.8 | 24.2% |
| All years in cohort | Q1 ratio | 15 | 274.5 | 15.7% |
| All years in cohort | Q1 + previous Q2 ridge | 15 | 221.4 | 13.1% |

### Financial and price-ratio models, matched price-available years

| Period | Model | Years | MAE (USD m) | MAPE |
|---|---|---:|---:|---:|
| 2012–2021 development | Previous Q2 | 6 | 207.9 | 15.4% |
| 2012–2021 development | Original weather ridge | 6 | 219.8 | 16.4% |
| 2012–2021 development | Q1 ratio | 6 | 206.8 | 15.8% |
| 2012–2021 development | Q1 + previous Q2 ridge | 6 | 183.9 | 14.4% |
| 2012–2021 development | Nitrogen price ratio | 6 | 107.3 | 7.9% |
| 2022–2026 previously inspected | Previous Q2 | 5 | 853.6 | 37.8% |
| 2022–2026 previously inspected | Original weather ridge | 5 | 884.4 | 38.4% |
| 2022–2026 previously inspected | Q1 ratio | 5 | 396.2 | 17.4% |
| 2022–2026 previously inspected | Q1 + previous Q2 ridge | 5 | 299.8 | 13.0% |
| 2022–2026 previously inspected | Nitrogen price ratio | 5 | 147.0 | 7.3% |
| All years in cohort | Previous Q2 | 11 | 501.4 | 25.6% |
| All years in cohort | Original weather ridge | 11 | 521.9 | 26.4% |
| All years in cohort | Q1 ratio | 11 | 292.9 | 16.5% |
| All years in cohort | Q1 + previous Q2 ridge | 11 | 236.6 | 13.8% |
| All years in cohort | Nitrogen price ratio | 11 | 125.3 | 7.6% |

### All models including fitted price models, matched later years

| Period | Model | Years | MAE (USD m) | MAPE |
|---|---|---:|---:|---:|
| 2022–2026 previously inspected | Previous Q2 | 5 | 853.6 | 37.8% |
| 2022–2026 previously inspected | Original weather ridge | 5 | 884.4 | 38.4% |
| 2022–2026 previously inspected | Q1 ratio | 5 | 396.2 | 17.4% |
| 2022–2026 previously inspected | Q1 + previous Q2 ridge | 5 | 299.8 | 13.0% |
| 2022–2026 previously inspected | Nitrogen price ratio | 5 | 147.0 | 7.3% |
| 2022–2026 previously inspected | Q1 + price ridge | 5 | 419.2 | 16.4% |
| 2022–2026 previously inspected | Q1 + price + weather ridge | 5 | 413.9 | 17.1% |
| All years in cohort | Previous Q2 | 5 | 853.6 | 37.8% |
| All years in cohort | Original weather ridge | 5 | 884.4 | 38.4% |
| All years in cohort | Q1 ratio | 5 | 396.2 | 17.4% |
| All years in cohort | Q1 + previous Q2 ridge | 5 | 299.8 | 13.0% |
| All years in cohort | Nitrogen price ratio | 5 | 147.0 | 7.3% |
| All years in cohort | Q1 + price ridge | 5 | 419.2 | 16.4% |
| All years in cohort | Q1 + price + weather ridge | 5 | 413.9 | 17.1% |

## Why the original errors were large

The earlier baseline carried last year’s Q2 revenue into the next year. This could not anticipate abrupt company-wide shifts. CF reported that Q1 net sales rose from USD 1,048m in 2021 to USD 2,868m in 2022. In Q1 2023, CF reported net sales of USD 2,012m and its UAN segment had a 28% lower average selling price per ton than Q1 2022, reflecting higher global supply availability and lower energy costs. These company disclosures offer a plausible explanation of the large errors; this is descriptive and does not establish causation.
Sources: [CF Q1 2022 filing](https://www.sec.gov/Archives/edgar/data/1324404/000132440422000016/cf-20220331.htm), [CF Q1 2023 filing](https://www.sec.gov/Archives/edgar/data/1324404/000132440423000012/cf-20230331.htm).

Signed error below is predicted minus actual; negative means underprediction.
- **2022 signed errors (USD m):** Previous Q2 -1,801.0; Original weather ridge -1,888.9; Q1 ratio +956.8; Q1 + previous Q2 ridge -755.5.
- **2023 signed errors (USD m):** Previous Q2 +1,614.0; Original weather ridge +1,729.8; Q1 ratio +602.5; Q1 + previous Q2 ridge +490.6.

## Coverage and limits

- Complete common feature rows: 21; time-ordered prediction years: 2012–2026. Omitted years/reasons: none.
- Q1 is taken from an exact January–March company-wide fact filed by May 31; the company serves other regions, crops and industrial customers.
- Nitrogen producer prices use the ALFRED graph’s May 31 as-of vintage and exact current/prior April dates; individual revision dates were not exposed. The index is a national proxy, not CF’s realized prices.
- Each ridge uses the existing fixed penalty and fold-only scaling; all parameters are re-estimated at each historical prediction date. Changes in weather effects or Q1/Q2 seasonality can still cause errors. The price-equipped models have fewer training years; the weather-plus-price model has five predictors and can overfit badly.
- Historical NASA weather may have been revised; original weather availability was not reconstructed. Small samples, structural shifts and trying several candidates limit the strength of any comparison.
- The 2007 Q1 figure is the initially reported 447.7m; a later correction was unavailable at the 2007 cutoff. The 2005 Q1 value is a pre-IPO predecessor figure from a 2006 annual filing; the 2009 Q1 value is from an earnings release.
- The simple nitrogen-price ratio is a retrospective candidate, not a proven forecasting model: its selection used these already-seen data. Freeze it before evaluating a future season. If the April index vintage is missing at the cutoff, use the previous-Q2 baseline and record the fallback.
- The already-seen 2022–2026 outcomes are not a fresh holdout. Freeze a candidate and evaluate on a future season such as 2027 before claiming prospective improvement.
- Per-year predictions and signed errors are in `predictions_private.csv`. Do not upload datasets or generated results to GitHub.
