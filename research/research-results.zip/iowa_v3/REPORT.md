# Iowa fertilizer revenue: exploratory new-data checks

All years through 2026 have already been inspected. These are post-hoc comparisons, not an untouched test; all models in each cohort use exactly the same years. The original April WPU065201 price-ratio candidate remains frozen.

## Matched historical results

MAE is mean absolute error in USD millions. Lower is better.

### Alternative Price

| Period | Model | Years | MAE (USD m) | MAPE |
|---|---|---:|---:|---:|
| 2016-2021 | Frozen nitrogen-price ratio | 6 | 107.3 | 7.9% |
| 2016-2021 | Alternative producer price ratio (PCU325311325311A) | 6 | 95.6 | 7.0% |
| 2022-2026 | Frozen nitrogen-price ratio | 5 | 147.0 | 7.3% |
| 2022-2026 | Alternative producer price ratio (PCU325311325311A) | 5 | 160.1 | 7.3% |
| all | Frozen nitrogen-price ratio | 11 | 125.3 | 7.6% |
| all | Alternative producer price ratio (PCU325311325311A) | 11 | 124.9 | 7.1% |

- **Alternative producer price ratio (PCU325311325311A):** did not reduce error in both periods. This comparison is exploratory and cannot validate future performance.

### Q1 Volume

| Period | Model | Years | MAE (USD m) | MAPE |
|---|---|---:|---:|---:|
| 2016-2021 | Frozen nitrogen-price ratio | 6 | 107.3 | 7.9% |
| 2016-2021 | Frozen price ratio × Q1 volume ratio | 6 | 252.0 | 19.9% |
| 2022-2026 | Frozen nitrogen-price ratio | 5 | 147.0 | 7.3% |
| 2022-2026 | Frozen price ratio × Q1 volume ratio | 5 | 79.8 | 3.8% |
| all | Frozen nitrogen-price ratio | 11 | 125.3 | 7.6% |
| all | Frozen price ratio × Q1 volume ratio | 11 | 173.8 | 12.6% |

- **Frozen price ratio × Q1 volume ratio:** did not reduce error in both periods. This comparison is exploratory and cannot validate future performance.

### Both

| Period | Model | Years | MAE (USD m) | MAPE |
|---|---|---:|---:|---:|
| 2016-2021 | Frozen nitrogen-price ratio | 6 | 107.3 | 7.9% |
| 2016-2021 | Alternative producer price ratio (PCU325311325311A) | 6 | 95.6 | 7.0% |
| 2016-2021 | Frozen price ratio × Q1 volume ratio | 6 | 252.0 | 19.9% |
| 2016-2021 | Alternative producer price ratio × Q1 volume ratio | 6 | 245.3 | 19.5% |
| 2022-2026 | Frozen nitrogen-price ratio | 5 | 147.0 | 7.3% |
| 2022-2026 | Alternative producer price ratio (PCU325311325311A) | 5 | 160.1 | 7.3% |
| 2022-2026 | Frozen price ratio × Q1 volume ratio | 5 | 79.8 | 3.8% |
| 2022-2026 | Alternative producer price ratio × Q1 volume ratio | 5 | 94.0 | 3.9% |
| all | Frozen nitrogen-price ratio | 11 | 125.3 | 7.6% |
| all | Alternative producer price ratio (PCU325311325311A) | 11 | 124.9 | 7.1% |
| all | Frozen price ratio × Q1 volume ratio | 11 | 173.8 | 12.6% |
| all | Alternative producer price ratio × Q1 volume ratio | 11 | 176.6 | 12.4% |

- **Alternative producer price ratio (PCU325311325311A):** did not reduce error in both periods. This comparison is exploratory and cannot validate future performance.
- **Alternative producer price ratio × Q1 volume ratio:** did not reduce error in both periods. This comparison is exploratory and cannot validate future performance.
- **Frozen price ratio × Q1 volume ratio:** did not reduce error in both periods. This comparison is exploratory and cannot validate future performance.

## Limitations and next steps

- Alternative price values use the same May 31 ALFRED vintage for both April values; the nitrogen index is a national proxy and is not CF’s realized price.
- Q1 sales volume is for product tons, not Iowa-specific corn fertilizer sales; its use assumes Q1 volume changes are informative about Q2 volume changes.
- Simple formulas have no fitted parameters, but their comparison and any selection occurred after the historical outcomes were known.
- Features may cover different years. Compare only rows within the same cohort, and treat small samples and acquisitions/plant outages cautiously.
- A real new test requires a future season such as 2027: archive inputs and the candidate before observing Q2 results.
- Year-by-year actuals, predictions, errors and feature provenance remain in the output files.
