# Iowa corn-season fertilizer revenue: exploratory research

## Question and scope

On May 31, can Iowa precipitation forecasts and CF Industries Q1 shipments improve a price-based estimate of CF’s Q2 company-wide net sales? The selected P12 feature is the forecast probability of at least 0.01 inch of liquid-equivalent precipitation during lead hours 12–24; it is not observed rain, total rainfall, or fertilizer purchases. The company sells to markets well beyond Iowa corn. This is a nowcast after part of Q2 has elapsed; correlation does not establish causation.

## Information timeline

The decision date is May 31. The price baseline uses prior-Q2 sales and the current/prior April nitrogen price-index ratio. The weather feature summarizes forecasts initialized from April 1 through May 20, a window of up to 50 dates, requiring at least 40 available dates per station; the shipment factor uses Q1 company product tons filed by the cutoff. The weather regression uses earlier Q2 outcomes filed by the cutoff and training-only scaling. A future target is assessed after its Q2 filing. Historical feature availability and actual publication times require the replay audit below; a date in a snapshot alone is not proof.

## Matched comparison

Each year has the same decision date and target for all four methods. Weather uses the original centered, no-intercept ridge correction. Shipments use the fixed square root of the current/prior Q1 shipment ratio; the both model applies both effects. The shipment multiplier was explored after examining historical outcomes.

Mean absolute revenue error in USD millions; negative Δ versus price means the model improved on price alone.

| Period | Model | Years | Mean absolute error | Δ versus price |
|---|---|---:|---:|---:|
| 2016–2021 | Price | 6 | 107.3 | +0.0 |
| 2016–2021 | Price + weather | 6 | 109.0 | +1.7 |
| 2016–2021 | Price + shipments | 6 | 163.4 | +56.2 |
| 2016–2021 | Price + both | 6 | 166.0 | +58.7 |
| 2022–2026 | Price | 5 | 147.0 | +0.0 |
| 2022–2026 | Price + weather | 5 | 148.7 | +1.7 |
| 2022–2026 | Price + shipments | 5 | 113.4 | -33.6 |
| 2022–2026 | Price + both | 5 | 116.9 | -30.1 |

Year-by-year values in USD millions. Each model cell is **prediction (signed error) [lower, upper]**; signed error is prediction minus actual. A dash means a range could not yet be calculated.

| Year | Actual | Price | Price + weather | Price + shipments | Price + both |
|---:|---:|---:|---:|---:|---:|
| 2016 | 1,134.0 | 1,111.8 (-22.2) — | 1,114.4 (-19.6) — | 1,311.3 (+177.3) — | 1,314.4 (+180.4) — |
| 2017 | 1,124.0 | 1,071.9 (-52.1) — | 1,071.5 (-52.5) — | 1,160.1 (+36.1) — | 1,159.6 (+35.6) — |
| 2018 | 1,300.0 | 1,126.6 (-173.4) — | 1,130.6 (-169.4) — | 1,072.9 (-227.1) — | 1,076.6 (-223.4) — |
| 2019 | 1,502.0 | 1,306.5 (-195.5) — | 1,297.9 (-204.1) — | 1,273.3 (-228.7) — | 1,264.9 (-237.1) — |
| 2020 | 1,204.0 | 1,287.2 (+83.2) [1,091.7, 1,482.7] | 1,293.3 (+89.3) [1,089.3, 1,497.4] | 1,378.6 (+174.6) [1,149.9, 1,607.3] | 1,385.1 (+181.1) [1,148.1, 1,622.2] |
| 2021 | 1,588.0 | 1,470.7 (-117.3) [1,275.3, 1,666.2] | 1,469.1 (-118.9) [1,265.0, 1,673.1] | 1,451.2 (-136.8) [1,222.5, 1,679.9] | 1,449.5 (-138.5) [1,212.4, 1,686.6] |
| 2022 | 3,389.0 | 3,426.2 (+37.2) [3,230.7, 3,621.7] | 3,425.9 (+36.9) [3,221.8, 3,629.9] | 3,448.7 (+59.7) [3,220.0, 3,677.4] | 3,448.3 (+59.3) [3,211.2, 3,685.4] |
| 2023 | 1,775.0 | 1,986.9 (+211.9) [1,791.4, 2,182.4] | 1,974.3 (+199.3) [1,770.3, 2,178.4] | 1,967.7 (+192.7) [1,739.0, 2,196.4] | 1,955.2 (+180.2) [1,718.2, 2,192.3] |
| 2024 | 1,572.0 | 1,575.1 (+3.1) [1,363.2, 1,787.0] | 1,554.3 (-17.7) [1,350.2, 1,758.4] | 1,573.2 (+1.2) [1,344.5, 1,801.9] | 1,552.4 (-19.6) [1,315.3, 1,789.5] |
| 2025 | 1,890.0 | 1,691.6 (-198.4) [1,496.1, 1,887.1] | 1,630.1 (-259.9) [1,430.7, 1,829.4] | 1,779.0 (-111.0) [1,551.9, 2,006.2] | 1,714.4 (-175.6) [1,491.0, 1,937.7] |
| 2026 | 2,222.0 | 2,506.4 (+284.4) [2,307.9, 2,704.8] | 2,451.7 (+229.7) [2,247.7, 2,655.8] | 2,424.6 (+202.6) [2,197.5, 2,651.8] | 2,371.8 (+149.8) [2,148.4, 2,595.1] |

## Uncertainty and observed coverage

Ranges use the same model’s earlier out-of-sample absolute errors whose Q2 outcomes had been filed by the decision date. The 80% finite rank is ceil((n+1) × 0.8); a finite range requires at least four prior errors. Lower bounds are clipped at zero. Missing ranges and unavailable outcomes are excluded from the coverage denominator, rather than counted as failures. Eligible matching pre-window folds from 2016 onward may provide additional calibration errors; the separate calibration inventory lists unavailable or insufficient earlier folds. Their provenance is audited separately.

| Period | Model | Covered / evaluated | Observed coverage |
|---|---|---:|---:|
| 2016–2021 | Price | 2 / 2 | 100.0% |
| 2016–2021 | Price + shipments | 2 / 2 | 100.0% |
| 2016–2021 | Price + weather | 2 / 2 | 100.0% |
| 2016–2021 | Price + both | 2 / 2 | 100.0% |
| 2022–2026 | Price | 2 / 5 | 40.0% |
| 2022–2026 | Price + shipments | 5 / 5 | 100.0% |
| 2022–2026 | Price + weather | 3 / 5 | 60.0% |
| 2022–2026 | Price + both | 5 / 5 | 100.0% |

The series is very short, model and feature choices were informed by the same historical outcomes, and errors may change over time. The nominal 80% is a construction target, not a reliable calibration or a coverage guarantee. Actual past availability and out-of-sample execution of the archived predictions are not proven merely by calculating a range.

## Recorded negative and mixed findings

Labels such as holdout_2026 describe the original plan; those outcomes have since been inspected and are no longer untouched holdouts.

- In 2016–2021, the price-only error was USD 107.3m; these additions had higher average errors on the same years: Price + weather: USD 109.0m; Price + shipments: USD 163.4m; Price + both: USD 166.0m.
- In 2022–2026, the price-only error was USD 147.0m; these additions had higher average errors on the same years: Price + weather: USD 148.7m.
- Original observed-weather ridge (development; years 2012, 2013, 2014, 2015, 2016, 2017, 2018, 2019, 2020, 2021): USD 249.0m average error versus previous-Q2 USD 173.8m and revenue-only ridge USD 191.2m; it did not beat both comparisons. Scores: `original/iowa_corn_revenue/scores_private.csv`; matched-year summaries: `original/iowa_corn_revenue/predictions_private.csv`.
- Original observed-weather ridge (holdout_2026; years 2026): USD 578.8m average error versus previous-Q2 USD 332.0m and revenue-only ridge USD 551.0m; it did not beat both comparisons. Scores: `original/iowa_corn_revenue/scores_private.csv`; matched-year summaries: `original/iowa_corn_revenue/predictions_private.csv`.
- Earlier shipment investigation, matched years 2016, 2017, 2018, 2019, 2020, 2021: base USD 107.3m; full USD 252.0m; damped USD 163.4m. Scores: `primary/iowa_v4/scores_private.csv`; annual diagnostics: `primary/iowa_v4/yearly_diagnostics_private.csv`. These are reported separately from the four-model comparison above.
- The separate full-history intercept sensitivity had higher average error in 2022–2026 with the half correction (USD 188.3m) than without it (USD 148.7m). See `primary/iowa_intercept_research/scores_private.csv`.
- In the 2022 fieldwork investigation, absolute errors were USD 186.3m for the six-week model, 39.7m for the matched one-week model, and 45.3m for forecast-only. Source: `primary/iowa_fieldwork_2022/annual_private.csv`. These are retrospective sensitivities.
- In 2023, the longer-history fieldwork comparison had USD 116.8m absolute error with the prior history and USD 219.8m after adding older years; the change was USD +103.1m. Source: `primary/iowa_missing_fieldwork/paired_private.csv`.
- In 2026, the longer-history fieldwork comparison had USD 187.7m absolute error with the prior history and USD 260.0m after adding older years; the change was USD +72.3m. Source: `primary/iowa_missing_fieldwork/paired_private.csv`.
- In the 2025 sensitivity investigation, absolute errors were USD 254.5m with the previous weather and shipment adjustment, 184.2m with the halved weather adjustment, and 111.0m for price plus shipments. Source: `primary/iowa_forecast_further_2025/annual_errors_private.csv`. These variants were chosen after inspecting historical results.

Other retained model scores, including the original observed-weather and earlier full-shipment investigations, are indexed in the experiment register. Their distinct cohorts and historical versions must be read from their source artifacts; they should not be compared as if they used these exact folds.

## Replay and source provenance

The strict replay records eligible, missing, after-cutoff and unverified inputs rather than filling unknown availability with later information. Counts below are input requirements, not independent observations or proof of publication.

| Decision date | Replay status | Required inputs |
|---|---|---:|
| 2016-05-31 | unverified_candidates | 77 |
| 2017-05-31 | unverified_candidates | 86 |
| 2018-05-31 | unverified_candidates | 95 |
| 2019-05-31 | unverified_candidates | 104 |
| 2020-05-31 | unverified_candidates | 113 |
| 2021-05-31 | unverified_candidates | 122 |
| 2022-05-31 | unverified_candidates | 131 |
| 2023-05-31 | unverified_candidates | 140 |
| 2024-05-31 | unverified_candidates | 149 |
| 2025-05-31 | unverified_candidates | 158 |
| 2026-05-31 | unverified_candidates | 167 |

The [National Weather Service MOS glossary](https://forecast.weather.gov/glossary.php?word=model+output+statistics) describes its short-range MOS guidance package as generally available around 04:00 UTC for 00:00 forecast cycles and 16:00 UTC for 12:00 cycles. This general guidance does not establish the issuance or availability time of any specific historical IEM record.

[FRED release-date documentation](https://fred.stlouisfed.org/docs/api/fred/releases_dates.html) says the data source’s release date does not necessarily indicate when that data became available on FRED or ALFRED. This distinction also applies when interpreting archived price-vintage evidence.

Neither generic description establishes the input vintages or clears any unverified input in the strict replay. Generic timings are not assigned as individual publication timestamps or used to change replay statuses.

Archived weather selections can rebuild the saved aggregates, but their original issue/publication availability and revision history are not independently established. Older price reconstructions and other saved transcriptions require source and vintage checks. A checksum checks saved bytes; it does not prove that they support the claimed value or source, or establish historical availability. Replay also depends on separately reviewed source assertions. If strict replay shows unverified or missing inputs, exact historical reconstruction remains incomplete.

## Verification of evaluated outcomes

Each scored Q2 outcome and its stated filing date are checked separately from prediction-time inputs. The counts below are evidence requirements, not independent observations. The filing-date check assumes the recorded source availability is the claimed filing day; a separate earlier earnings release needs a separately modeled date.

| Outcome or filing status | Requirements |
|---|---:|
| blocked_by_outcome | 11 |
| unverified_candidates | 11 |

Unverified or missing outcomes prevent strict replay even when the prediction-time inputs pass.

## Experiment record and interpretation

The register contains 1440 retained artifact rows spanning 25 named studies. Rows include score records, individual prediction and incremental-comparison source rows, and summaries of prediction or diagnostic files; the same model may appear more than once. These counts are not the number of unique trials, and unrecorded attempts or original proposal timing may be missing. All outcomes through 2026 had been inspected by the time the register was reconstructed.

Before recording a new proposal or result in `new_experiments_private.jsonl`, carry that log forward from saved output. The notebook does not automatically create a replacement when the previous log is absent. Its working directory is ephemeral; preserve each updated log with the notebook output and retain an independent trusted head and count when possible.

All comparisons here are retrospective and exploratory. The historical exercise provides no fresh holdout. The pre-existing 2027 price-only prospective test remains unchanged; record its inputs and prediction at the cutoff, then evaluate only after the Q2 result is filed.

## Sources and audit trail

- [ALFRED real-time data documentation](https://fred.stlouisfed.org/docs/api/fred/realtime_period.html): as-of vintages can differ from the latest revised observations. Not every saved historical price has independently verified vintage evidence.
- [NOAA GFS MOS format guide](https://www.weather.gov/media/mdl/mdltpb05-03.pdf): P12 is a 12-hour precipitation probability, with the 24-hour projection ending the lead-hours 12–24 interval.
- [SEC filings search](https://www.sec.gov/search-filings): original company financial and shipment disclosures and their filing dates.
- [Iowa Environmental Mesonet MOS forecast data endpoint](https://mesonet.agron.iastate.edu/cgi-bin/request/mos.py): archived model forecast records; current archive retrieval does not prove historical publication time or absence of revisions.
- [Kaggle research notebook and outputs](https://www.kaggle.com/code/nicolasrster/iowa-fertilizer-revenue-price-follow-up/output): see `iowa_incremental_value`, `iowa_exploratory_ranges`, `iowa_replay`, and the experiment register for row-level evidence and results.

## Capture integrity requirement

The workflow requires a local SHA-256-matched artifact for every evidence type before strict replay can be complete. A match checks current bytes only; it does not prove that those bytes support a value, that a source is genuine, or that the artifact existed or was public by the historical cutoff. Those claims require independent source- and time-specific review.

## Training cohort completeness

The audit checks each earlier annual candidate, including excluded years, against its declared filing date and the fold cutoff. Later evidence is used only to audit the historical cohort, not as a prediction input. Counts are conditional on a complete supplied ledger.

- Cohort included_outcome_unverified: 121
- Filing filing_unverified: 121

## Calibration context and verification

Earlier matching folds from 2016 onward contribute filed errors where available. Only requested years are shown as predictions above. Preparation alone does not verify provenance; strict replay also audits every used earlier fold, its training cohort and its outcome. The inventory records missing or unbuildable folds.

Earlier calibration years used: none. Skipped candidate folds: 0.
