# 2025 forecast error: exploratory investigation

The price-only prediction was $1,691.6m against actual revenue $1,890.0m. The annual forecast feature was 19.57%, versus prior-years' mean 25.73% (z=-2.32, prior range 20.93–30.58%). Its fitted coefficient was 0.0507; the full model multiplied the price prediction by 0.889, moving it to $1,503.5m and worsening absolute error from $198.4m to $386.5m.

Two post-hoc sensitivities are compared with the same price-only and full predictions in the same five rolling years: half the log adjustment and, separately, clipping the forecast feature to the range of the training years. They use the original coefficients and only earlier-year information, but were selected after inspecting these results. They are not independent tests or proven improvements. See scores_private.csv for MAE, wins, and sensitivity to excluding a test year; see yearly_diagnostic_private.csv for annual results and training-range diagnostics. The frozen 2027 protocol is unchanged.

The model used precipitation probability at three Iowa stations, not rain amount or actual farmer orders. This statistical diagnosis does not identify the cause of company revenue or establish that an individual farmer used the forecast. Q2 company disclosures are after the May 31 prediction cutoff and are explanations only, never inputs.

Sources: https://www.sec.gov/Archives/edgar/data/1324404/000132440425000024/cf-20250630.htm ; https://www.nass.usda.gov/Statistics_by_State/Iowa/Publications/Crop_Progress_%26_Condition/2025/IA-Crop-Progress-05-12-25.pdf ; https://www.sec.gov/Archives/edgar/data/1324404/000132440425000013/cf-05072025_ex991xearnings.htm
