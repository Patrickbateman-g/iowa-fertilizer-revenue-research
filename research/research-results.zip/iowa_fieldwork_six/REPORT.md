# Six-week Iowa fieldwork comparison

The six-week feature averages statewide days suitable for fieldwork over the six consecutive weeks ending on or before May 20. One-week features use the final week of the same six. Reports must be dated by May 31. Some entries are previous-week values from a later dated report and can incorporate revisions available at that time. Some reports are hosted by a university or reproduced by news outlets; the stored source date is that of the document actually used. Report contents and release dates were manually transcribed and not independently reverified by the notebook.

Only years with all six reports and matching forecast and price data enter either model; both windows use identical expanding training folds, training-only scaling, six prior observations minimum and fixed ridge penalty. Joined years: 11; comparable test years: 5. The six-week price+forecast+fieldwork model had lower absolute error than the matched one-week model in 3 of 5 years. Full results are stored alongside source dates, coverage, and missing weeks.

This is a retrospective research comparison after prior years were inspected, with very few annual examples. It does not establish causal effects or prove future improvement. Fieldwork suitability is not farmer orders and covers all farm activities. The frozen 2027 forecast is unchanged.
