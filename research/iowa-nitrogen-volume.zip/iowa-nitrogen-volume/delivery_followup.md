# Follow-up: estimating January–June deliveries in Iowa
The original rain analysis used an expanding historical average as its benchmark. I examined a previous-year benchmark, a trailing three-year mean and a previous-year estimate adjusted for rainfall change on the same six 2019–2024 evaluation years. These are exploratory comparisons of known outcomes.

Before calculating the fall-based results, I specified a seasonal balance estimate: mean total nitrogen distributed over the last three completed July–June crop years, minus the current crop year's July–December distribution. Apply a floor of zero tons. Prior fall data are reported in the state crop-year tables, whose final publication follows June; I have not verified that the specific fall figures were publicly available by the historical May cutoffs. This estimate tests a physical mechanism retrospectively and is conditional on access to fall tonnage.

For a like-for-like weather check, center the spring rain adjustment on the last three years of weather and estimate the rain slope on earlier years only. Compare the trailing three-year spring mean both with and without this correction. Score mean absolute error in nutrient tons, on identical years. All outcomes were previously inspected. A better score is exploratory. No change to the CF forecast protocol.

## Results
I originally used the mean of every earlier spring. For the new estimate I use the median of the three preceding spring volumes. The median comparison was added after inspecting other candidate scores. It had the smallest mean absolute error among the eight estimates on these six already-examined years.

| Estimate | 2019–2024 mean absolute error (nitrogen tons) |
|---|---:|
| All earlier springs, mean | 159,101 |
| Original rain model | 144,072 |
| Previous spring | 152,015 |
| Previous spring + rain change | 196,733 |
| Three recent springs, mean | 112,972 |
| Three recent springs, median | 92,005 |
| Three recent springs, mean + rain | 148,150 |
| Three crop years minus prior fall | 162,438 |

The recent median improved on the full-history mean in all six years. The average gap fell by about 67,096 tons (42.2%). The three-year mean comparison separates the effect of using a shorter history from switching to the middle value. In 2024 the median estimate was 510,013 tons, compared with 499,888 reported. The 2020 median missed by about 311,000 tons. The lower retrospective error needs testing on new data.

Run `python3 iowa_delivery_estimates.py --annual` next to the CSV files or the repository study ZIP. Fall product tonnages are transcribed from the July–December column in each report linked in paired.csv; that fall precedes the spring named in the row.

## Adding rain to the three-spring median
Before scoring this follow-up, I chose the exact rain correction already used with the three-spring mean. For each May 31 estimate I start with the median of the preceding three spring delivery volumes. I add the difference between current spring rainfall and the preceding three springs’ mean rainfall, multiplied by the rainfall slope fitted to all earlier years’ rainfall and deliveries. The slope has units of nutrient tons per millimeter. Only the volume baseline changes between the two rain-adjusted methods. I compare with the unadjusted median on the same six years by mean absolute error and report every paired result.

Rain helped in four of six years, but mean absolute error rose from 92,005 to 137,610 nutrient tons (+49.6%). In 2024 the rain-adjusted estimate was 908,319 tons and the state reported 499,888. Across 2019–2023 alone, rain reduced the mean miss by 24,935 tons. This last comparison diagnoses the influence of 2024; the primary score includes all six years. Retain the median alone pending new observations.

| Year | Median absolute miss (tons) | Rain-adjusted absolute miss (tons) |
|---|---:|---:|
| 2019 | 119,514 | 100,237 |
| 2020 | 310,890 | 206,820 |
| 2021 | 39,563 | 64,528 |
| 2022 | 31,576 | 27,231 |
| 2023 | 40,358 | 18,411 |
| 2024 | 10,125 | 408,431 |

## Diagnosis and range-limited rain adjustment
In 2021, dry weather called for a modest cut. The median was 549,577 tons and Iowa reported 510,013. The model cut 104,091 tons, over twice the 39,563-ton cut needed. Its slope was sensitive to 2020, a dry, low-volume year: omitting 2020 roughly halves the earlier-years slope (3,333 to 1,573 tons/mm). Rain in 2021 was within the earlier range. At nearly the same rainfall as 2020, the four-grade volume rebounded about 129,000 tons, mostly in urea and UAN 32.

In 2024, spring rain reached 216.9 mm versus 98.9 mm in the preceding three springs and a previous sample high of 184.3 mm. At 3,374 tons per extra millimeter, the 118.0 mm difference added 398,306 tons to a median already within 10,125 tons of the outcome. The wet-end extrapolation alone accounts for about 110,000 tons of the increase. The rest reflects the steep slope and the unusually dry three-year reference. Against 2023, gains in UAN 32 were outweighed by lower anhydrous-ammonia deliveries. The semiannual distribution records cannot identify what caused individual purchases.

I tested one guardrail on every year: clip the adjusted prediction to the lowest and highest delivery volumes of the three preceding springs. Only the 2024 prediction changed. Its upper bound was 518,795 tons (reported 499,888), reducing that miss to 18,907. The 2021 miss remained 64,528 tons because the prior range was wide. Across six years mean absolute error was 72,689 tons, versus 92,005 for the median and 137,610 for unbounded rain. I chose this rule after seeing the failure. I would track it alongside the median on new data.

| Year | Median miss | Rain-adjusted miss | Range-limited miss |
|---|---:|---:|---:|
| 2019 | 119,514 | 100,237 | 100,237 |
| 2020 | 310,890 | 206,820 | 206,820 |
| 2021 | 39,563 | 64,528 | 64,528 |
| 2022 | 31,576 | 27,231 | 27,231 |
| 2023 | 40,358 | 18,411 | 18,411 |
| 2024 | 10,125 | 408,431 | 18,907 |
