# Spring rain and Iowa nitrogen distribution

Across 11 paired years (2014–2024), the correlation between April 1–May 20 rain and January–June nitrogen distribution was +0.445. The descriptive slope was +1,429 nutrient tons per extra millimeter of three-location mean rainfall. Across 10 consecutive year-to-year changes the correlation was +0.510.

With at least five prior years of training, six retrospective May 31 estimates (2019–2024) gave mean absolute errors of 159,101 nutrient tons using the prior training mean and 144,072 with rain, a 9.4% reduction. The weather estimate was closer in five of six years. A supplemental leave-one-year-out check of the descriptive correlation ranged from +0.30 to +0.82.

The price-plus-weather revenue result answers a separate question: for 2022–2026, mean absolute error in CF Q2 revenue was $148.7m versus $147.0m for price alone.

Input notes: the state tables cover distribution to all Iowa markets. In 2014–2019 straight-material rows are keyed by N-P-K grade (82-0-0, 46-0-0, 32-0-0 and 28-0-0). Later reports also give product names. For each row, the July–December and January–June values were checked against the crop-year total. Rain comes from the project's retained NASA POWER annual feature table (iowa_v2/annual_features_private.csv, rain_mm); no forecast-probability input was used. Run python3 analyze.py next to paired.csv to reproduce the protocol metrics.

Uncertainty: geographic and time aggregation, product substitution, pre-season deliveries, revisions, crop area and other year effects could explain part of the association. The statewide outcome includes activity before April. Exact historical publication times were not verified. No farm-level use, causal response, commercial forecast validation or prospective 2027 result is established.

[Official state report index](https://iowaagriculture.gov/commercial-feed-and-fertilizer-bureau/commercial-fertilizer) · [NASA POWER daily data](https://power.larc.nasa.gov/docs/services/api/temporal/daily/)
