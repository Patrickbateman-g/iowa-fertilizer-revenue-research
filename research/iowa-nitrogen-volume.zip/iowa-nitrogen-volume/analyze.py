import csv
from math import sqrt
from pathlib import Path
from statistics import mean


def fit(x, y):
    mx, my = mean(x), mean(y)
    cross = sum((a-mx)*(b-my) for a,b in zip(x,y))
    sx = sum((a-mx)**2 for a in x)
    sy = sum((b-my)**2 for b in y)
    slope = cross/sx
    return my-slope*mx, slope, cross/sqrt(sx*sy)


with Path(__file__).with_name("paired.csv").open() as source:
    rows = list(csv.DictReader(source))
years = [int(r["year"]) for r in rows]
rain = [float(r["rain_mm"]) for r in rows]
volume = [float(r["nitrogen_tons"]) for r in rows]
assert years == list(range(2014,2025))
_, slope, correlation = fit(rain, volume)
print(f"Levels: slope {slope:.1f} tons/mm, correlation {correlation:.3f}")
dx = [b-a for a,b in zip(rain, rain[1:])]
dy = [b-a for a,b in zip(volume, volume[1:])]
print(f"Consecutive changes: correlation {fit(dx,dy)[2]:.3f}")
baseline_errors, weather_errors = [], []
for i in range(5,len(years)):
    intercept, slope, _ = fit(rain[:i],volume[:i])
    baseline_errors.append(abs(volume[i]-mean(volume[:i])))
    weather_errors.append(abs(volume[i]-intercept-slope*rain[i]))
print(f"Expanding-window MAE, {years[5]}–{years[-1]}: baseline {mean(baseline_errors):,.0f}, rain {mean(weather_errors):,.0f} nutrient tons.")
