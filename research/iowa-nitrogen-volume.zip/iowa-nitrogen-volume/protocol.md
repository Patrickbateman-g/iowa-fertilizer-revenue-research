# Iowa rain and regional nitrogen distribution
Recorded before fitting on 2026-11-06, after inspecting the 2024 report layout. Exploratory retrospective study.

Region and target: Iowa statewide, January–June. Sum nutrient tons in four named fertilizer products: NH3, urea, UAN 32 and UAN 28. Multiply each half-year product tonnage by its printed nitrogen fraction. All crops and suppliers. Exclude a year if any required row is missing or ambiguous. Use all comparable paired years in the state distribution index (2014–2024). No imputation. This basket is a proxy for nitrogen volume. Six-month totals cannot resolve purchases after individual storms.

Predictor: observed April 1–May 20 rainfall (millimeters), averaged over the project's three Iowa NASA POWER cells. May 31 cutoff. State reports cover through June 30; semiannual reporting is due in July. Exact first public report dates are unknown. Use volumes as retrospective outcomes; previous-year data availability is assumed for replay, not timestamp-verified.

Primary association: Pearson correlation and ordinary linear slope of volume on rain. Nonpositive slope weakens the proposed positive association. Predictive check: expanding-window fit with intercept, minimum five earlier matched years, compared with the earlier-years mean on identical evaluation years. Mean absolute error at least as high as the baseline weakens predictive usefulness. Also report association in year-over-year changes on consecutive pairs to check for trends. No threshold or product selection based on fit.
